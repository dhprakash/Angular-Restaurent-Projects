import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'


@Injectable({
  providedIn: 'root'
})
export class CommonService {
  URL="http://localhost:3000/resto";
  constructor( private http:HttpClient) { }

  getRestoList(){
    return this.http.get(this.URL);
  }

  addResto(data){
    return this.http.post(this.URL, data);
  }

  deleteResto(id){
    return this.http.delete(`${this.URL}/${id}`)
  }

  getCurrentData(id){
    return this.http.get(`${this.URL}/${id}`)
  }

  updateResto(id,date){
    return this.http.put(`${this.URL}/${id}`, date)
  }
}
