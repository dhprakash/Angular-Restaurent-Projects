import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-list-restourent',
  templateUrl: './list-restourent.component.html',
  styleUrls: ['./list-restourent.component.css']
})
export class ListRestourentComponent implements OnInit {
  alert:boolean=false;
  public collection:any;
  constructor(private CommonService:CommonService) { }

  deleteResto(resto){
    this.collection.splice(resto.id,1)
    this.CommonService.deleteResto(resto).subscribe((result=>{
      console.log("Data is Deleted Successfully !", result)
      this.alert=true;
    }))
  }

  ngOnInit(): void {
    this.CommonService.getRestoList().subscribe((result=>{
      this.collection=result;
      console.log(this.collection)
      }))
  }

  closeAlert(){
    this.alert=false;
  }


}
