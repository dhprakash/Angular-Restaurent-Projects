import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListRestourentComponent } from './list-restourent/list-restourent.component';
import { AddRestaurentComponent } from './add-restaurent/add-restaurent.component';
import { UpdateRestaurentComponent } from './update-restaurent/update-restaurent.component';


const routes: Routes = [
  {path:'list-restourent', component:ListRestourentComponent},
  {path:'add-restaurent', component:AddRestaurentComponent},
  {path:'update-restaurent/:id',component:UpdateRestaurentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
